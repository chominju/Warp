﻿// MeshTool.cpp: 구현 파일
//

#include "pch.h"
#include "MapTool.h"
#include "MeshTool.h"
#include "afxdialogex.h"


// CMeshTool 대화 상자

IMPLEMENT_DYNAMIC(CMeshTool, CDialogEx)

CMeshTool::CMeshTool(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DIALOG2, pParent)
{

}

CMeshTool::~CMeshTool()
{
}

void CMeshTool::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CMeshTool, CDialogEx)
END_MESSAGE_MAP()


// CMeshTool 메시지 처리기
