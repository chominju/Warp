﻿// ColliderTool.cpp: 구현 파일
//

#include "pch.h"
#include "MapTool.h"
#include "ColliderTool.h"
#include "afxdialogex.h"


// CColliderTool 대화 상자

IMPLEMENT_DYNAMIC(CColliderTool, CDialogEx)

CColliderTool::CColliderTool(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DIALOG3, pParent)
{

}

CColliderTool::~CColliderTool()
{
}

void CColliderTool::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CColliderTool, CDialogEx)
END_MESSAGE_MAP()


// CColliderTool 메시지 처리기
