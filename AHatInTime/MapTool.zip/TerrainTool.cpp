﻿// TerrainTool.cpp: 구현 파일
//

#include "pch.h"
#include "MapTool.h"
#include "TerrainTool.h"
#include "afxdialogex.h"
#include "MainFrm.h"
#include "MapTool.h"
#include "FileInfo.h"



// CTerrainTool 대화 상자

IMPLEMENT_DYNAMIC(CTerrainTool, CDialogEx)

CTerrainTool::CTerrainTool(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DIALOG1, pParent)
{

}

CTerrainTool::~CTerrainTool()
{
}

void CTerrainTool::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST1, m_terrainList);
}


BEGIN_MESSAGE_MAP(CTerrainTool, CDialogEx)
//	ON_WM_DROPFILES()
	ON_LBN_SELCHANGE(IDC_LIST1, &CTerrainTool::OnLbnSelchangeList1)
	ON_BN_CLICKED(IDC_BUTTON2, &CTerrainTool::OnBnClickedButton2)
	ON_WM_DROPFILES()
END_MESSAGE_MAP()


// CTerrainTool 메시지 처리기


void CTerrainTool::OnLbnSelchangeList1()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
}


void CTerrainTool::OnBnClickedButton2()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
}



void CTerrainTool::OnDropFiles(HDROP hDropInfo)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.

	CString sFileList(_T("")); // 파일 리스트 표시 
	TCHAR szFileName[MAX_PATH] = { 0, }; // 파일 명 반환할 변수 
	int iCount = ::DragQueryFile(hDropInfo, 0xFFFFFFFF, szFileName, sizeof(szFileName)); // ::DragQueryFile( 핸들, 0xFFFFFFFF로 하면 드롭된 갯수 가져옴 , 파일명 반환, 버퍼 크기 ); 
	for (int iIndex = 0; iIndex < iCount; iIndex++)
	{
		memset(szFileName, 0, sizeof(szFileName));
		::DragQueryFile(hDropInfo, iIndex, szFileName, sizeof(szFileName)); CString sFileName;
		sFileName.Format(_T("%s"), szFileName); sFileList += sFileName + _T("\n");
	} AfxMessageBox(sFileList);
	::DragFinish(hDropInfo);
	CDialogEx::OnDropFiles(hDropInfo);
}


BOOL CTerrainTool::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	DragAcceptFiles(true); ChangeWindowMessageFilterEx(m_hWnd, WM_DROPFILES, MSGFLT_ALLOW, NULL); ChangeWindowMessageFilterEx(m_hWnd, WM_COPYDATA, MSGFLT_ALLOW, NULL); ChangeWindowMessageFilterEx(m_hWnd, 0x0049/*WM_COPYGLOBALDATA*/, MSGFLT_ALLOW, NULL);

	// TODO:  여기에 추가 초기화 작업을 추가합니다.

	return TRUE;  // return TRUE unless you set the focus to a control
				  // 예외: OCX 속성 페이지는 FALSE를 반환해야 합니다.
}
