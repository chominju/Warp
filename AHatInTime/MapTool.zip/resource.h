﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++에서 생성한 포함 파일입니다.
// MapTool.rc에서 사용되고 있습니다.
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_MapToolTYPE                 130
#define IDD_CForm                       310
#define IDD_CColliderTool               313
#define IDD_DIALOG1                     315
#define IDD_CMapToolDialog              316
#define IDD_DIALOG2                     317
#define IDD_DIALOG3                     318
#define IDC_TAB2                        1012
#define IDC_TAB1                        1014
#define IDC_BUTTON1                     1015
#define IDC_EDIT1                       1016
#define IDC_EDIT2                       1021
#define IDC_EDIT3                       1022
#define IDC_EDIT4                       1023
#define IDC_EDIT5                       1024
#define IDC_EDIT6                       1025
#define IDC_SPIN2                       1026
#define IDC_SPIN3                       1027
#define IDC_EDIT7                       1028
#define IDC_SPIN4                       1029
#define IDC_SPIN5                       1030
#define IDC_SPIN6                       1031
#define IDC_SPIN7                       1032
#define IDC_EDIT8                       1033
#define IDC_EDIT9                       1034
#define IDC_EDIT10                      1035
#define IDC_SPIN8                       1036
#define IDC_SPIN9                       1037
#define IDC_SPIN10                      1038
#define IDC_LIST1                       1040
#define IDC_RADIO1                      1043
#define IDC_RADIO2                      1044
#define IDC_EDIT11                      1045
#define IDC_EDIT13                      1047
#define IDC_SPIN11                      1048
#define IDC_BUTTON2                     1049
#define IDC_SPIN13                      1050
#define IDC_BUTTON3                     1051

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        325
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1052
#define _APS_NEXT_SYMED_VALUE           317
#endif
#endif
