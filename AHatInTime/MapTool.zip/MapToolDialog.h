﻿#pragma once


// CMapToolDialog 대화 상자
class CTerrainTool;
class CMeshTool;
class CColliderTool;

class CMapToolDialog : public CDialogEx
{
	DECLARE_DYNAMIC(CMapToolDialog)

public:
	CMapToolDialog(CWnd* pParent = nullptr);   // 표준 생성자입니다.
	virtual ~CMapToolDialog();

	CTerrainTool* m_terrainTool;
	CMeshTool * m_meshTool;
	CColliderTool * m_colliderTool;

// 대화 상자 데이터입니다.
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_CMapToolDialog };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 지원입니다.

	DECLARE_MESSAGE_MAP()
public:
	CTabCtrl m_mapToolTab;
	virtual BOOL OnInitDialog();
	afx_msg void OnTcnSelchangeTab1(NMHDR *pNMHDR, LRESULT *pResult);
};
