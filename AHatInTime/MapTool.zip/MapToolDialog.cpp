﻿// MapToolDialog.cpp: 구현 파일
//

#include "pch.h"
#include "MapTool.h"
#include "MapToolDialog.h"
#include "afxdialogex.h"
#include "TerrainTool.h"
#include "MeshTool.h"
#include "ColliderTool.h"


// CMapToolDialog 대화 상자

IMPLEMENT_DYNAMIC(CMapToolDialog, CDialogEx)

CMapToolDialog::CMapToolDialog(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_CMapToolDialog, pParent)
{

}

CMapToolDialog::~CMapToolDialog()
{
}

void CMapToolDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_TAB2, m_mapToolTab);
}


BEGIN_MESSAGE_MAP(CMapToolDialog, CDialogEx)
	ON_NOTIFY(TCN_SELCHANGE, IDC_TAB1, &CMapToolDialog::OnTcnSelchangeTab1)
END_MESSAGE_MAP()


// CMapToolDialog 메시지 처리기


BOOL CMapToolDialog::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// TODO:  여기에 추가 초기화 작업을 추가합니다.

	m_mapToolTab.InsertItem(0, _T("Terrain"));
	m_mapToolTab.InsertItem(1, _T("Mesh"));
	m_mapToolTab.InsertItem(2, _T("Collider"));

	m_mapToolTab.SetCurSel(0);

	CRect rect;
	m_mapToolTab.GetWindowRect(&rect);

	m_terrainTool = new CTerrainTool;
	m_terrainTool->Create(IDD_DIALOG1, &m_mapToolTab);
	m_terrainTool->MoveWindow(0, 25, rect.Width(), rect.Height());
	m_terrainTool->ShowWindow(SW_SHOW);

	m_meshTool = new CMeshTool;
	m_meshTool->Create(IDD_DIALOG2, &m_mapToolTab);
	m_meshTool->MoveWindow(0, 25, rect.Width(), rect.Height());
	m_meshTool->ShowWindow(SW_HIDE);

	m_colliderTool = new CColliderTool;
	m_colliderTool->Create(IDD_DIALOG3, &m_mapToolTab);
	m_colliderTool->MoveWindow(0, 25, rect.Width(), rect.Height());
	m_colliderTool->ShowWindow(SW_HIDE);

	return TRUE;  // return TRUE unless you set the focus to a control
				  // 예외: OCX 속성 페이지는 FALSE를 반환해야 합니다.
}


void CMapToolDialog::OnTcnSelchangeTab1(NMHDR *pNMHDR, LRESULT *pResult)
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.

	int sel = m_mapToolTab.GetCurSel();

	switch (sel)
	{
	case 0:
		m_terrainTool->ShowWindow(SW_SHOW);
		m_meshTool->ShowWindow(SW_HIDE);
		m_colliderTool->ShowWindow(SW_HIDE);
		break;

	case 1:
		m_terrainTool->ShowWindow(SW_HIDE);
		m_meshTool->ShowWindow(SW_SHOW);
		m_colliderTool->ShowWindow(SW_HIDE);
		break;

	case 2:
		m_terrainTool->ShowWindow(SW_HIDE);
		m_meshTool->ShowWindow(SW_HIDE);
		m_colliderTool->ShowWindow(SW_SHOW);
		break;
	default:
		break;
	}



	*pResult = 0;
}
